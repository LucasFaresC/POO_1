public class TstPes{

	public static void main(String arg[]){//classLoader
	
		Leitura l1 = new Leitura();
		
		Aluno a1 =  new Aluno();
	
		a1.calcVal();
		a1.mostraVal();

	}
}
