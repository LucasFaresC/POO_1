// Lucas Fares Corrêa Auad Pereira
// RA: 2706652

public interface Calc {
    float calcularPreco(float precoBase);
}