public class Endereco{ //Classe Entidade

	private int num = 0;
	private String rua = "";
	
	public int getNum(){
		return num;		
	}
	public String getRua(){
		return rua;		
	}
	
	public void setNum(int num){
		this.num = num;		
	}
	
	public void setRua(String rua){
		this.rua = rua;		
	}
}