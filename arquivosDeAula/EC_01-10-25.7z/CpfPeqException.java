public class CpfPeqException extends Throwable{

	public CpfPeqException(){
		System.out.println("\nGerou um objeto do tipo CpfPeqException");
		
	}

}