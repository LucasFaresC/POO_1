public interface Calculadora{
	
	int valor = 10;
	
	public void calcVal();
	public void printDados();

}