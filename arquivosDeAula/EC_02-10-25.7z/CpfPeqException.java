public class CpfPeqException extends Exception{

	public CpfPeqException(){
		System.out.println("\nGerou um objeto do tipo CpfPeqException");
		
	}

}