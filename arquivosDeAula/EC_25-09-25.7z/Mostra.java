public interface Mostra{

	public void mostraVal();

}