public class CpfGrdException extends Exception{

	public CpfGrdException(){
		System.out.println("\nGerou um objeto do tipo CpfGrdException");
		
	}

}