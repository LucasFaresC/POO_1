public class CpfGrdException extends Exception{

	public void impErrCpfGrd(){
		System.out.println("\n O CPF deve ser um inteiro menor que 100");
	}

}