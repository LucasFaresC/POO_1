import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Leitura{
	
	public static Leitura leituraUnic; //1º Passo
	
	private Leitura(){} //2º Passo
	
	public static Leitura geraLeitura(){ //3º Passo
		if(leituraUnic == null){
			leituraUnic = new Leitura();			
		}
		return leituraUnic;
	}

	public static String entDados(String rotulo){
		
		System.out.println(rotulo);
		
		InputStreamReader tec = new InputStreamReader(System.in); 
		BufferedReader buff = new BufferedReader(tec);
		
		String ret = "";
		
		try{
				ret = buff.readLine();
		}
		catch(IOException ioe){
			System.out.println("\nERRO: JVM - RAM");
		}
		
		return ret;
	} 

}