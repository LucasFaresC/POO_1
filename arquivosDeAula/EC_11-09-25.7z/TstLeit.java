public class TstLeit{

	public static void main(String arg[]){
	
	
		Leitura l1 = Leitura.geraLeitura();
		Leitura l2 = Leitura.geraLeitura();
		Leitura l3 = Leitura.geraLeitura();
		
		//Leitura l4 = new Leitura(); //ERRO de ACESSO
		
		System.out.println("Ender de L1: "+ l1);
		System.out.println("Ender de L2: "+ l2);
		System.out.println("Ender de L3: "+ l3);
		System.out.println("Ender de L4: "+ l4);

	
	
	}


}
