// Lucas Fares Corrêa Auad Pereira
// RA: 2706652

public class DataInvalidaException extends Exception {
    
    public DataInvalidaException(String mensagem) {
        super(mensagem);
    }
}