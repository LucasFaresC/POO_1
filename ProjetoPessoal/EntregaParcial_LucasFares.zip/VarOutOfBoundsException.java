// Lucas Fares Corrêa Auad Pereira
// RA: 2706652

public class VarOutOfBoundsException extends Exception {
    public VarOutOfBoundsException(String mensagem) {
        super(mensagem);
    }
}