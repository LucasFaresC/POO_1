// Lucas Fares Correa Auad Pereira

public class TstDoub{
    // i) Classe Double: métodos parseDouble() e isInfinite()
    // ii) Converte String para double e verifica se é infinito
    /// iii) Referencia 
    public void converterEVerificar(String str) {
        double numero = Double.parseDouble(str);
        boolean infinito = Double.isInfinite(numero);
        
    }
}