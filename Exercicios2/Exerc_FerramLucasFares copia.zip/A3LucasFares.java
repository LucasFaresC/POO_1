
public class A3LucasFares {
    public static void main(String args[]) {
        System.out.println("Meu nome é " + args[0]);
    }
}
