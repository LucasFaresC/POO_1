// Lucas Fares Corrêa Auad Pereira

public interface Calc {
    
    int calcular();

}