public class TstTratExc{

	public static void main(String arg[]){//classLoader
	
		Leitura l1 = new Leitura();
		Pessoa p1 = new Pessoa();
try{		
	p1.setCpf(Integer.parseInt(l1.entDados("\nCPF..: ")));
}
catch(CpfPeqException cpe){
		System.out.println("\nEntrou no CATCH de CpfPeqException");
}

System.out.println("\nCPF...: " + p1.getCpf());
				
	
	}
}
/*
TRY --> Tente executar tal método
CATCH --> Captura um objeto lançado por try
*/