// Lucas Fares Corrêa Auad Pereira

public class TstFloat {
    /*
    i) Classe Float metodo toString e parseFloat
    ii) converteStringFloat tranforma uma string em float, e um float em uma string
    iii) Referencia Documentação da Oracle
     */
    public void  converteStringFloat(float f, String s){
        String palavra = Float.toString(f);
        float flutuante = Float.parseFloat(s);
    }
    

}