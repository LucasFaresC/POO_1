public class TstPes{

	public static void main(String arg[]){//classLoader
	
		Leitura l1 = new Leitura();
		
		Pessoa p1 = new Pessoa();
				
		System.out.println("\nCPF: "+p1.getCpf());
		System.out.println("NOME: "+p1.getNome());		

		Pessoa p2 = new Pessoa(340, "Emet",new Endereco());
				
		System.out.println("\nCPF: "+p2.getCpf());
		System.out.println("NOME: "+p2.getNome());		


	/*	
		p1.setCpf(Integer.parseInt(l1.entDados("\nCPF..: ")));
		p1.setNome(l1.entDados("NOME: "));
		p1.getEnder().setRua(l1.entDados("\nRUA..:")); //Reflexidade
		p1.getEnder().setNum(Integer.parseInt(l1.entDados("NUM..: "))); //Reflexidade
	
		l1.entDados("\nPress key to continue...");
	
		System.out.println("\nCPF: "+p1.getCpf());
		System.out.println("NOME: "+p1.getNome());
		System.out.println("\nRUA_R: "+p1.getEnder().getRua()); //Reflexidade
		System.out.println("NUMERO_R: "+p1.getEnder().getNum());//Reflexidade
	*/		
	}
}
